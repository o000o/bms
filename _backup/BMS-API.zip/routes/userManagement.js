'use strict'
const logger = require('../utils/logUtils')
const async = require('async')
const resp = require('../utils/respUtils')
const util = require('../utils/bmsUtils')
const jsUtil = require('util')
const error = require('../config/error')
const cst = require('../config/constant')
const mUser = require('../models/mUser')

const userManagement = {
    add: (req, res) => {
        let cmd = 'AddUserManagement'
        try {
            if (!util.isDataFound(req.body.requestData.userName)) {
              let err = 'userName can not null'
              logger.error(req, cmd + '|Error:' + err)
              logger.summary(req, cmd + '|' + error.code_00005)
              return res.json(resp.getJsonError(error.code_00005, error.desc_00005, err))
            }

            let jWhere = {
                userName: req.body.requestData.userName,
            }
            mUser.findOrCreate({
                where: jWhere,
                defaults: req.body.requestData,
            }).spread((db, succeed) => {
                if (succeed) {
                    logger.info(req, cmd + '|Data:' + JSON.stringify(req.body.requestData) + '|Create complete')
                    return resp.getSuccess(req, res, cmd, db)
                } else { //vendor existed
                    logger.info(req, cmd + '|Error:' + error.desc_01004)
                    logger.summary(req, cmd + '|Error:' + error.desc_01004)
                    return res.json(resp.getJsonError(error.code_01004, error.desc_01004, db))
                }
            }).catch((err) => {
                logger.error(req, cmd + '|Data:' + JSON.stringify(req.body.requestData) + '|Error:' + err)
                logger.summary(req, cmd + '|' + error.desc_01001)
                return res.json(resp.getJsonError(error.code_01001, error.desc_01001, err))
            })
        } catch (err) {
            logger.error(req, cmd + '|' + err)
            return resp.getInternalError(req, res, cmd, err)
        }
    },
    edit: (req, res) => {
        let cmd = 'UpdateUserManagement'
        try {
            if (!util.isDataFound(req.body.requestData.userName)) {
              let err = 'userName can not null'
              logger.error(req, cmd + '|Error:' + err)
              logger.summary(req, cmd + '|' + error.code_00005)
              return res.json(resp.getJsonError(error.code_00005, error.desc_00005, err))
            }

            mUser.update(req.body.requestData, {
                  where: {
                      userName: req.body.requestData.userName
                  }
            }).then((succeed) => {
              if (succeed > 0) {
                logger.info(req, cmd + '|\"userName\":\"' + req.params.userName + '\"|Update complete ' + succeed + ' records')
                return resp.getSuccess(req, res, cmd)
              } else {
                let err = 'Not Found userName ' + req.params.userName
                logger.summary(req, cmd + '|\"userName\":\"' + req.params.userName + '\"|Update complete '+ succeed + ' records|' + err)
                return res.json(resp.getJsonError(error.code_01003, error.desc_01003, err))
              }
            }).catch((err) => {
                logger.error(req,cmd + '|Error:' + err)
                logger.summary(req,cmd+'|'+error.desc_01001)
                return res.json(resp.getJsonError(error.code_01001,error.desc_01001,err))
            })
        } catch (err) {
            logger.error(req, cmd + '|' + err)
            return resp.getInternalError(req, res, cmd, err)
        }
    },
    delete: (req, res) => {
        let cmd = 'DeleteUserManagement'
        try {
          if (!util.isDataFound(req.params.userName)) {
            let err = 'userName can not null'
            logger.error(req, cmd + '|Error:' + err)
            logger.summary(req, cmd + '|' + error.code_00005)
            return res.json(resp.getJsonError(error.code_00005, error.desc_00005, err))
          }

          logger.info(req, cmd + '|Data:\"userName\": \"' + req.params.userName )
          mUser.destroy({
                where: {
                    userName: req.params.userName
                }
          }).then((succeed) => {
              if (succeed > 0) {
                logger.info(req, cmd + '|\"userName\":\"' + req.params.userName + '\"|Data:' + succeed + ' records')
                return resp.getSuccess(req, res, cmd)
              } else {
                let err = 'Not Found userName ' + req.params.userName
                logger.summary(req, cmd + '|\"userName\":\"' + req.params.userName + '\"|Data:' + err)
                return res.json(resp.getJsonError(error.code_01003, error.desc_01003, err))
              }
            }).catch((err) => {
                logger.error(req, cmd + '|\"userName\":\"' + req.params.userName + '\"|Error:' + err)
                logger.summary(req, cmd + '|' + error.desc_01001)
                return res.json(resp.getJsonError(error.code_01001, error.desc_01001, err))
            })
        } catch (err) {
            logger.error(req, cmd + '|' + err)
            return resp.getInternalError(req, res, cmd, err)
        }
    },
    queryByCriteria: (req, res) => {
        let cmd = 'QueryUserManagement'
        try {

            const jLimit = {
                offset: null,
                limit: null
            }

            if (Object.keys(req.query).length != 0) {
                cmd= 'CheckPageCount'
                if (util.isDigit(req.query.page) && util.isDigit(req.query.count)) {
                    jLimit.offset = (req.query.page - 1) * req.query.count
                    jLimit.limit = parseInt(req.query.count)
                    logger.info(req, cmd +'|PageCount:' + JSON.stringify(jLimit))
                } else {
                    logger.summary(req, cmd + '|page or count is wrong format')
                    return resp.getIncompleteParameter(req, res, cmd)
                }
            }

            let jWhere = {}
            cmd = 'CheckuserManagementCriteria'
            logger.info(req, cmd + '|Data:Found userManagementCriteria:' + util.isDataFound(req.body.requestData.userManagementCriteria))
            if (util.isDataFound(req.body.requestData.userManagementCriteria)) {
                jWhere = req.body.requestData.userManagementCriteria
            }
            //add paging in to jwhere
            cmd = 'CheckPagging'
            jWhere.offset = jLimit.offset
            jWhere.limit = jLimit.limit
            logger.info(req, cmd + '|Data:' + util.jsonToText(jWhere, {
                showHidden: false,
                depth: null
            }))

            cmd = 'FindUserManagement'
            mUser.findAndCountAll(jWhere).then((db) => {
                cmd = 'GetUsermanagement'
                if (db.count > 0) {
                  logger.info(req, cmd + '|Data:' + JSON.stringify(db))
                    return resp.getSuccess(req, res, cmd, {
                        "totalRecord": db.count,
                        "userManagementList": db.rows
                    })
                } else {
                    logger.info(req, cmd + '|Data:' + JSON.stringify(db) + '|Not Found userManagementList')
                    logger.summary(req, cmd + '|Not Found userManagementList')
                    return res.json(resp.getJsonError(error.code_01003, error.desc_01003, db))
                }
            }).catch((err) => {
                logger.error(req, cmd + '|Error:' + err)
                logger.summary(req, cmd + '|' + error.desc_01002)
                return res.json(resp.getJsonError(error.code_01002, error.desc_01002, err))
            })

        } catch (err) {
            logger.error(req, cmd + '|' + err)
            return resp.getInternalError(req, res, cmd, err)
        }
    }
}
module.exports = userManagement
